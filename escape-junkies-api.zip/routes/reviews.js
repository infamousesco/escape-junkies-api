const express = require("express");
const router = express.Router();
const Review = require("../models/Review");
const private = require("./privateRoute");

router.get("/reviews", async (req, res) => {
  try {
    const reviews = await Review.find();
    res.json(reviews);
  } catch (err) {
    res.json({ message: err });
  }
});

//Find specific review
router.get("/reviews/:id", async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    res.json(review);
  } catch (err) {
    res.json({ message: err });
  }
});

router.put("/reviews/:id", private, async (req, res) => {
  const id = req.params.id;

  const updatedReview = {
    title: req.body.title,
    reviewBody: req.body.reviewBody,
  };
  try {
    const review = await Review.findById(id);

    if (review.author === req.user.id) {
      const editReview = await Review.findOneAndUpdate(id, updatedReview);
      res.status(200).json({ message: "Review updated successfully!" });
    } else {
      res
        .status(401)
        .json({ message: "You do not have permission to update this review." });
    }
  } catch (err) {
    res.json({ message: err });
  }
});

router.post("/reviews", private, async (req, res) => {
  const review = new Review({
    title: req.body.title,
    reviewBody: req.body.reviewBody,
    author: req.user.id,
  });
  try {
    const savedReview = await review.save();
    res.status(200).json({ message: "Review created successfully!" });
  } catch (err) {
    res.status(400).json({
      message:
        "Sorry please try submitting your review again. Make sure you have a valid title and something in the review area.",
    });
  }
});

module.exports = router;
